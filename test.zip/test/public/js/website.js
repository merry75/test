angular.module('website', ['ngRoute', 'ui.bootstrap']).
    config(function ($routeProvider) {
        $routeProvider.
            when('/screen/:symbol?', {templateUrl: 'partials/screen.html', controller: 'ScreenCtrl'}).
            when('/home', {templateUrl: 'partials/home.html', controller: 'HomeCtrl'}).
            otherwise({redirectTo: '/home'});
    })
    .controller('ScreenCtrl', function ($scope, $http, $routeParams) {
        $scope.message = $routeParams.symbol;
    })
    .controller('HomeCtrl', function ($scope, $http, $q, $location) {
        $scope.news = [
            {
                title: 'News Item1', img: 'http://lorempixel.com/400/200/', date: 1469959781804, description: 'Description 1'
            }, {
                title: 'News Item2', img: 'http://lorempixel.com/400/200/food', date: 1468029434776, description: 'Description 2'
            }, {
                title: 'News Item3', img: 'http://lorempixel.com/400/200/sports', date: 1469192218634, description: 'Description 3'
            }, {
                title: 'News Item4', img: 'http://lorempixel.com/400/200/people', date: 1469157574527, description: 'Description 4'
            }];

        $scope.myInterval = 3000;
        $scope.slides = [
            {
              image: 'http://lorempixel.com/400/200/'
            },
            {
              image: 'http://lorempixel.com/400/200/food'
            },
            {
              image: 'http://lorempixel.com/400/200/sports'
            },
            {
              image: 'http://lorempixel.com/400/200/people'
            }
        ]; 

        $scope.sortFactor = 'title';
        $scope.currentNews = 0;
        $scope.visibleDescription = true;

        $scope.changeCurrentView = function(index) {
            if(index == $scope.currentNews) {
                $scope.visibleDescription = !$scope.visibleDescription;
            } else {
                $scope.visibleDescription = true;
            }
            $scope.currentNews = index;
        }

        $scope.showDate = function(d) {
            var date = new Date(d);
            return date.getFullYear() + ' / ' + (date.getMonth() + 1) + ' / ' + (date.getDay() + 1);
        }
    })