Installation
======================
cd into the test folder direct and npm start => go to localhost:8090

Building an AngularJS Website Using Routes
======================

This is a simple AngularJS website using routes and partials. I have also included StateService to show how to preserve state across route changes.

Other animation features :
-Latest news section:
 *You can filter the news item by date/name
 *You can display/hide a container for each news item to render whatever you want (text,img and so on)
-Image container:
 *You can see the according image of the news item in the image container
-Menu:
 *You can have submenus when hovering hover the menu
 *routing done with ui router and can navigate through different main menus



Technologies Used 
======================
angular
angular-ui-router
bootsrap
angular-ui-bootsrap
express to set up a quick localhost server

